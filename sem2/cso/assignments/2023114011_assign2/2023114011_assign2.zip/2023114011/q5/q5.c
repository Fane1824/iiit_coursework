#include <stdio.h>

long long int binary_search(long long int* L, long long int key, long long int* iterations);

int main() {
    long long int L[32];
    long long int key;
    long long int iterations = 0;
    for (int i = 0; i < 32; i++) {
        scanf("%lld", &L[i]);
    }
    scanf("%lld", &key);
    printf("%lld", binary_search(L, key, &iterations));
    printf(" %lld\n", iterations);
    return 0;
}
