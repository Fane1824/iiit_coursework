#include <stdio.h>
#include <stdlib.h>

long long int postfix(char input[], long long int n);

int main() {
    long long int n;
    scanf("%lld", &n);
    long long int size = n/2 + 1;
    char input[size];
    char buffer;
    scanf("%c", &buffer);
    for (int i = 0;i < size;i++){
        scanf("%c", &input[i]);
        char white_space;
        scanf("%c", &white_space);
    }
    printf("%lld\n", postfix(input, size));
    return 0;
}