#include <stdio.h>

long long int maxsum(long long int n, long long int l, long long int r, long long int a[]);

int main() {
    long long int n, l, r;
    scanf("%lld%lld%lld", &n, &l, &r);
    long long int a[n+1];
    a[0] = 0;
    for(long long int i = 1; i <= n; i++){
        scanf("%lld", &a[i]);
    }
    long long int ans = maxsum(n, l, r, a);
    printf("%lld\n", ans);
    return 0;
}