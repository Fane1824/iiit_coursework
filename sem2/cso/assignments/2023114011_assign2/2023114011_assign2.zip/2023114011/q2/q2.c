#include <stdio.h>

long long int combs(long long int n, long long int r); 

int main() {
    long long int n, r;
    scanf("%lld %lld", &n, &r);
    printf("%lld\n", combs(n, r));
    return 0;
}
