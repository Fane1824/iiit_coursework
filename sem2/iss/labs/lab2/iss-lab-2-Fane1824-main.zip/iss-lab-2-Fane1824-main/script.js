var a = 0;
var interval;
function switchfunc() {
  a = 1 - a;
  update();
}
// 1 is 12 hour time, 0 is 24 hour time
document.addEventListener("DOMContentLoaded", function() {
  
  function update() {
    let clock = document.querySelector("#clock");
    let now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();
    var setting;
    if (a == 1) {
      setting = "AM";
      if (hours >= 12) {
        setting = "PM";
      }
      if (hours > 12) {
        hours = hours - 12;
      }
      if (hours == 0) {
        hours = 0;
      } 
    }
    if (hours < 10) {
      hours = "0"+hours;
    }
    if (minutes < 10) {
      minutes = "0"+minutes;
    } 
    if (seconds < 10) {
      seconds = "0"+seconds;
    }
    if (a == 1) {
      var text = hours + ":" + minutes + ":" + seconds + " " + setting;
    } else {
      var text = hours + ":" + minutes + ":" + seconds;   
    }
    clock.innerHTML = text;
  }
  clearInterval(interval);
  update();
  interval = setInterval(update, 1000);

});
