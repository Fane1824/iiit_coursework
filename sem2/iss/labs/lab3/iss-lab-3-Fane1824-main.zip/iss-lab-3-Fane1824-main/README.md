# Introduction 

This is a demonstration of the usage of the Flask library in Python, making use of HTML to create a form in which the user inputs the data. After the data has been inputted, it is stored in a file and can be retrieved via searching from the address bar.

# Assumptions

1. The file "users.txt" is created before the execution of the program.
2. The file "users.txt" contains only the text "[]" before the execution of the program.
3. The details of the user can be requested by typing in`"<URL>/user/<username>"` into the address bar
4. When the details of the user are requested, the password is shown in encrypted form for security reasons.
