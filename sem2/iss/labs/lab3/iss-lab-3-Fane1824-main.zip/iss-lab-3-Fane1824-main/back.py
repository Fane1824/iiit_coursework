from flask import Flask, request, render_template
import bcrypt
import json
import os

def hash_pw(pw):
    hashedpw = bcrypt.hashpw(pw.encode('utf-8'), bcrypt.gensalt())
    return hashedpw.decode('utf-8')

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('form.html')

@app.route('/exroute', methods=['POST'])
def routemaker():
    name = request.form['name']
    email = request.form['email']
    password = hash_pw(request.form['password'])
    
    f = open("users.txt", "r")
    l = json.load(f)
    l += [{"name": name, "email": email, "password": password}]
    f.close()
    f = open("users.txt", "w")
    json.dump(l, f)
    f.close()
    return render_template('form.html', success_message="The operation was successful.")

@app.route('/user/<user_id>', methods=['GET']) 
def search(user_id):
    f = open("users.txt", "r")
    l = json.load(f)
    f.close()
    for i in l:
        if i["email"] == user_id:
            formatted_details = f"Name: {i['name']}<br>Email: {i['email']}<br>Password: {i['password']}"
            return formatted_details
    return "User not found. Please re-enter data."

if __name__ == "__main__":
    app.run()


