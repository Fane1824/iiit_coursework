# Introduction

This file contains details regarding the files used, functions called and data structures used, alongside any assumptions made, in the Assignment 1 of Data Structures & Algorithms. 

# Purpose of the Code

This project implements a simple social media platform, allowing users to create and delete posts, comments and replies, and navigate through the posts, comments, and replies.

# Files Used

Header Files:

1. reply.h:
   - Contains declarations of functions and structures related to replies, specifically the structure `Reply` and function `createReply`.

2. comment.h:
   - Contains declarations of functions and structures related to comments, specifically the structure `Comment` and function `createComment`.

3. post.h:
   - Contains declarations of functions and structures related to posts, specifically the structure `Post` and function `createPost`.

4. platform.h:
   - Contains declarations of functions and structures related to the social media platform and its functionality, specifically the structure `Platform` and functions `createPlatform`, `addPost`, `deletePost`, `viewPost`, `currPost`, `nextPost`, `previousPost`, `addComment`, `deleteComment`, `viewComments`, `addReply`, `deleteReply`.
.

Implementation Files:

5. reply.c:
   - Implementation file containing the definitions of functions declared in reply.h. This file includes the implementation of the `createReply` function, which dynamically allocates memory for a new reply structure, initializes its attributes, and returns a pointer to the newly created reply.

6. comment.c:
   - Implementation file containing the definitions of functions declared in comment.h. This file includes the implementation of the `createComment` function, which dynamically allocates memory for a new comment structure, initializes its attributes, and returns a pointer to the newly created comment.

7. post.c:
   - Implementation file containing the definitions of functions declared in post.h. This file includes the implementation of the `createPost` function, which dynamically allocates memory for a new post structure, initializes its attributes, and returns a pointer to the newly created post.

8. platform.c:
   - Implementation file containing the definitions of functions declared in platform.h. It provides the functionality necessary to utilize the social media platform, specifically to browse different posts, comments, and replies, alongside the ability to add them to the platform after creation and removal from the platform after deletion. 

Main File:

9. main.c:
   - Main file responsible for orchestrating the application flow. It includes code which permits the input of data from the user and also provides a mechanism for outputting error messages, alongside the data the user attempts to access. 

The modular design allows for clear separation of concerns, making it easier to understand and maintain different parts of the codebase independently. Additionally, it enables easier testing, debugging, and potential future enhancements or modifications.

# Data Structures Used

**1. struct `Reply`**: A structure to represent a reply, comprising the username of the replier (a string `Username`), the content of the reply (a string `Content`), and a pointer to the next reply in the reply linked list (`next`). This structure enables the organization of replies and facilitates navigation through them within the social media platform.

**2. struct `Comment`**:  A structure to represent a comment within a social media platform, comprising the username of the commenter (a string `Username`), the content of the comment (a string `Content`), associated replies (a pointer to the first reply `Replies`), a pointer to the next comment in the comment linked list (`next`), and the number of replies (`numreply`). This structure facilitates the organization and presentation of comments and replies within the social media platform, enhancing user interaction and engagement.

**3. struct `Post`**:  A structure to store post information within a social media platform, consisting of the username of the post creator (a string `Username`), the caption of the post (a string `Caption`), associated comments (a pointer to the first comment `Comments`), a pointer to the next post in the post linked list (`next`), and the number of comments (`numcomment`). This structure facilitates the management and display of posts and their interactions within the social media platform.

**4. struct `platform`**: A structure representing a platform within a social media context, including pointers to the first post (`Posts`) and the last viewed post (`lastViewedPost`), as well as an integer indicating the total number of posts (`numposts`). This structure serves as a foundational component for managing and navigating posts within the social media platform, facilitating user interactions and content dissemination.

# Functions 

## Functions in `reply.c` file

**1. `createReply(char* username, char* content)`:** Constructs a reply using the provided username and content parameters, returning a pointer to the created reply.

## Functions in `comment.c` file

**1. `createComment(char* username, char* content)`:** Generates a comment using the given username and content parameters, returning a pointer to the created comment.

## Functions in `post.c` file

**1. `createPost(char* username, char* caption)`:** Creates a post using the provided username and caption parameters, returning a pointer to the newly created post.

## Functions in `platform.c` file

**1. `createPlatform()`**: Creates a single instance of the platform data type, ensuring there's only one instance throughout the code. 

**2. `addPost(char* username, char* caption)`**: Creates a post with the given username and caption, adding it to the list of existing posts and indicating whether the process was successful. 

**3. `deletePost(int n)`**: Deletes the nth recent post, clearing associated comments and replies, and returns whether the deletion is successful. 

**4. `viewPost(int n)`**: Returns the nth recent post if it exists; otherwise, returns a NULL pointer. 

**5. `currPost()`**: Returns the last viewed post, which is the most recent post unless no post has been viewed, in which case it returns a NULL pointer. 

**6. `nextPost()`**: Returns the post that was posted just before the last viewed post; if the last viewed post is the first one added, it returns that post, or a NULL pointer in case of an error. 

**7. `previousPost()`**: Returns the post that was posted just after the last viewed post; if the last viewed post is the most recent one added, it returns that post, or a NULL pointer in case of an error. 

**8. `addComment(char* username, char* content)`**: Adds a comment to the last viewed post and returns whether the addition is successful. 

**9. `deleteComment(int n)`**: Deletes the nth recent comment to the last viewed post, clearing associated replies, and returns whether the deletion is successful. 

**10. `viewComments()`**: Returns a list of all comments to the last viewed post, ordered by the time of commenting, with the latest comments at the end. 

**11. `addReply(char* username, char* content, int n)`**: Adds a reply to the nth recent comment of the last viewed post, indicating whether the addition is successful. 

**12. `deleteReply(int n, int m)`**: Deletes the mth recent reply to the nth recent comment of the last viewed post, returning whether the deletion is successful. 

# Notes

1. The variable `chflag` is used to store whether a post has been viewed or not. When its value is equal to 0, then no post has been viewed and every new post added becomes the last viewed post. If its value is equal to 1, then a post has been viewed through either `current_post`, `previous_post`, `next_post`, `view_post`. 

2. The pointer to the platform `p` is used as a global instance in all functions where it is necessary to update or access a platform. 

# Assumptions
1. The program assumes that the input is provided in the predefined format. If the input does not follow the predefined format, the program may behave irregularly and/or incorrectly.
2. The program assumes that the username for `Comment`, `Reply`, and `Post` does not contain any spaces.
3. The program assumes that the username and caption for `Post`, and username and content for `Comment` and `Reply`, are a maximum of 100 characters long, each. 
4. The program assumes that the command `create_platform` is given first before any other command.


