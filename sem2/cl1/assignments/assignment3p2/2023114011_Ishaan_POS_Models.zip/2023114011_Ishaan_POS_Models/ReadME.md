# Testing CRF++ and HMM models

This assignment involves the training of two models, namely CRF (Conditional Random Fields) and HMM (Hiden Markov Models), using a given set of training data, alongside pre-prepared testing data (which was prepared in part 1 of the assignment). The implementation of HMM is via Python, while the usage of CRF is through the CRF++ toolkit. 

## General Instructions:
The following instructions are for regarding how to test the CRF and HMM models, and measure its precision, recall, and F1 score (expressed as percentages)

### I. Testing CRF++ Model

### Instructions:

1. **Download CRF++-0.58:** Obtain the CRF++ software package from the provided link. This tool is essential for training and testing Conditional Random Fields (CRF) models. Ensure that this is done on the Windows operating system and only the latest version is installed to provide consistency and accuracy.

2. **Installation of CRF++:** Follow the installation instructions provided on the CRF++ website (https://taku910.github.io/crfpp/) to set up the software on your system. Navigate to the CRF++ directory containing the data files in the format required for training.

3. **Data Preparation:** Convert the annotated data from Part 1 into the appropriate format compatible with CRF++ training. Ensure that the data adheres to the Universal Dependencies (UD) tagset.

4. **Template File Creation:** Create a template file that defines the feature templates to be used during training. This file will specify the context and features to be considered by the CRF model. In our case, the template file is attached within the CRF folder. The template was the following:
```
# Unigram
U00:%x[-1,0]
U01:%x[0,0]
U02:%x[1,0]
```

5. **Training the CRF Model:** Use the command `.\crf_learn <template> <training_data> model` command to train the CRF model using the provided training data and the template file. Ensure that the template file is correctly referenced.

6. **Testing the Model:** Employ the trained model to perform inference on the test data using the command `.\crf_test model <testing_data>`. Provide the path to the trained model file (model) and the test file containing re-annotated UD data.

7. **Evaluation:** Analyze the results obtained from the CRF model to assess its performance. The code used to measure the precision, recall, and F1 score is attached in the submission folder.

Repeat these steps for both French and English datasets to evaluate the CRF model performance accurately.

### II. Testing HMM Model

1. **Run code:** Run the provided code in the Jupyter notebook.

2. **Evaluation:** Analyze the results obtained from the HMM model to assess its performance. The output of the Jupyter notebook is the precision, recall, and F1 score.

Repeat these steps for both French and English datasets to evaluate the HMM model performance accurately.

### Dataset

The dataset used for French is an automatic conversion of the [French QuestionBank v1](http://alpage.inria.fr/Treebanks/FQB/), a corpus entirely made of questions.the 

The dataset used for English is the English portion of the Parallel Universal Dependencies (PUD) treebanks created for the CoNLL 2017 shared task on Multilingual Parsing

### Assumptions

1. Windows operating system is used while testing CRF to ensure smooth functioning. 
