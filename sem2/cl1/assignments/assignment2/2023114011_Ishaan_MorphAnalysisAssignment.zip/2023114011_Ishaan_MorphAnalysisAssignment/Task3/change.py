bases = []
parads = []
after_slash_lengths = []


def largest_common_substring(words):
    if not words:
        return ""
    reference_word = words[0]
    common_substring = ""
    for i, char in enumerate(reference_word):
        if all(len(word) > i and word[i] == char for word in words):
            common_substring += char
        else:
            break  
    return common_substring

def writerfunc(f, identity, gcontent):
    bwordslist = gcontent.split("Base word: ")
    for bword in bwordslist:
        if bword == "" or bword == "\n":
            continue
        lines=bword.split("\n") #splits lines
        wordlist = []
        taslist = []
        count = -1
        g_list = dict()
        sgpl_list = dict()
        for i in range(len(lines)): #uses numbers
            if (i == 0):
                bases.append(lines[i])
                wordlist.append(lines[i])
            elif (lines[i]).isalpha() == True:
                wordlist.append(lines[i].strip())
                count += 1
                g_list[count] = 0
                sgpl_list[count] = ""
            else:
                propertieslist = lines[i].split(",")
                if (len(propertieslist) > 2):
                    if "tense" in propertieslist[2]:
                        if "present" in propertieslist[2]:      
                            taslist.append("present")
                        elif "past" in propertieslist[2]:
                            taslist.append("past")
                        else:
                            taslist.append("future")
                    elif "aspect" in propertieslist[2]:
                        if "perfect" in propertieslist[2]:
                            taslist.append("perfect")
                        elif "progress" in propertieslist[2]:
                            taslist.append("progress")
                        elif "participle" in propertieslist[2]:
                            taslist.append("participle")
                        elif "gen" in propertieslist[2]:
                            taslist.append("gen")
                    elif "fem" in propertieslist[2]:
                        taslist.append("fem")
                    elif "masc" in propertieslist[2]:
                        taslist.append("masc")
                    elif "sg" in propertieslist[2]:
                        taslist.append("sg") 
                    elif "pl" in propertieslist[2]:
                        taslist.append("pl")                    
                if (len(propertieslist) > 3):
                    if "1" in propertieslist[3]:
                        g_list[count] = 1
                    elif "2" in propertieslist[3]:
                        g_list[count] = 2
                    elif "3" in propertieslist[3]:
                        g_list[count] = 3
                    if "sg" in propertieslist[3]:
                        sgpl_list[count] = "sg"
                    elif "pl" in propertieslist[3]:
                        sgpl_list[count] = "pl"
                if (len(propertieslist) > 4):
                    if "sg" in propertieslist[4]:
                        sgpl_list[count] = "sg"
                    elif "pl" in propertieslist[4]:
                        sgpl_list[count] = "pl"
        actualbase = largest_common_substring(wordlist)
        
        parads.append(actualbase+'/'+wordlist[0][len(actualbase):]+'__'+identity)
        after_slash_lengths.append(len(wordlist[0]) - len(actualbase))
        f.write('\t\t<pardef n="'+actualbase+'/'+wordlist[0][len(actualbase):]+'__'+identity+'">\n')
        wordlist.pop(0)
        counter = 0
        for word in range(len(wordlist)):
            f.write("\t\t\t<e>\n")
            f.write("\t\t\t\t<p>\n")
            if wordlist[word] == wordlist[0] and actualbase == wordlist[0]:
                f.write("\t\t\t\t\t<l/>\n")    
            else:
                f.write("\t\t\t\t\t<l>"+wordlist[word][len(actualbase):]+"</l>\n")
            f.write('\t\t\t\t\t<r>'+wordlist[0][len(actualbase):]+'<s n="'+identity+'"/><s n="'+taslist[counter]+'"/>')
            if (g_list[word] != 0):
                f.write('<s n="'+str(g_list[word])+'"/>')
            if (sgpl_list[word] != "" and sgpl_list[word] != taslist[word]):
                f.write('<s n="'+sgpl_list[word]+'"/>')
            f.write('</r>\n')
            counter += 1
            f.write("\t\t\t\t</p>\n")
            f.write("\t\t\t</e>\n")
        f.write("\t\t</pardef>\n")


freader = open("task1.txt", "r")
content = freader.readlines()
freader.close()

freader_t2 = open("task2.txt", "r")
content_t2 = freader_t2.readlines()
freader_t2.close()

f = open("ans.dix", "w")
f.write("<dictionary>\n")
f.write("\t<alphabet>abcçdeêéèfghijklmnopqrstuvwxyz</alphabet>\n")
f.write("\t<sdefs>\n")
f.write('\t\t<sdef n="n"/>\n\t\t<sdef n="sg"/>\n\t\t<sdef n="pl"/>\n\t\t<sdef n="1"/>\n\t\t<sdef n="2"/>\n\t\t<sdef n="3"/>\n\t\t<sdef n="gen"/>\n')
f.write('\t\t<sdef n="v"/>\n\t\t<sdef n="masc"/>\n\t\t<sdef n="fem"/>\n\t\t<sdef n="past"/>\n\t\t<sdef n="present"/>\n\t\t<sdef n="future"/>\n\t\t<sdef n="participle"/>\n\t\t<sdef n="progress"/>\n\t\t<sdef n="perfect"/>\n')
f.write("\t</sdefs>\n\n")
str1 = ""
for x in content:
    if (x != "\n"):
        str1 += x
str1 = str1.replace("English\n", "")
languages = str1.split("French\n")
english = languages[0]
french = languages[1]
english_split = english.split("Nouns")
writerfunc(f, "v", english_split[0])
writerfunc(f, "n", english_split[1])
french_split = french.split("Nouns")
writerfunc(f, "v", french_split[0])
writerfunc(f, "n", french_split[1])
f.write('\t<section id="main" type="standard">\n')
for line in content_t2:
    if "French" in line or "English" in line or line == "" or line == "\n":
        continue
    line = line.replace("\n", "")
    parts = line.split(",")
    x = bases.index(parts[2].strip())
    num = (-1) * after_slash_lengths[x]
    if (num != 0):
        f.write('\t\t<e lm="'+parts[0]+'"><i>'+parts[0][:num]+'</i><par n="'+parads[x]+'"/></e>\n')
    else:
        f.write('\t\t<e lm="'+parts[0]+'"><i>'+parts[0]+'</i><par n="'+parads[x]+'"/></e>\n')
f.write("\t</section>\n")
f.write("</dictionary>")
f.close()


