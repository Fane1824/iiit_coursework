import re

f = open("i2.txt", "r")
l = f.readlines()
f2 = open("o2.txt", "w")
for x in range(len(l)):
    f2.write(l[x])
    if (x % 3 == 1):
        sentence = l[x].replace("Text = ", "")
        tokens = re.findall(r"\b\w+(?:'\w+)?(?:’\w+)?|[^\w\s]", sentence)
        text = ['\tToken '+str(i+1)+' = '+str(tokens[i])+'\n' for i in range(len(tokens))]
        f2.writelines(text)
f.close()
f2.close()