import re

f = open("i4.txt", "r")
l = f.readlines()
f.close()
f2 = open("o4.txt", "w")
f3 = open("i4_2.txt", "r")
l2 = f3.readlines()
f3.close()
tsumk = len(l2)
tsumv = 0
for i in range(len(l2)):
    x = re.split(" ", l2[i])
    tsumv += int(x[1])
ans = {}
for x in range(len(l)-1):
    f2.write(l[x])
    if (l[x].startswith("\tToken")):
        tok = l[x].split("=", 1)
        vex = tok[1].strip()
        v = vex.lower()
        if (v in ans):
            ans[v] += 1
        else:
            ans[v] = 1
    if (l[x+1].startswith("</")):
        sumv = 0
        sumk = 0
        for value in ans.values():
            sumv += value
        for key in ans:
            sumk += 1
        ans.clear()
        f2.write("\tType-Token Ratio = "+str(sumk)+"/"+str(sumv)+" = "+str(round(float(sumk/sumv), 1))+"\n") 
f2.write(l[len(l)-1])  

f2.write("\nCumulative Type-Token Ratio = "+str(tsumk)+"/"+str(tsumv)+" = "+str(float(tsumk/tsumv)))
f2.close()