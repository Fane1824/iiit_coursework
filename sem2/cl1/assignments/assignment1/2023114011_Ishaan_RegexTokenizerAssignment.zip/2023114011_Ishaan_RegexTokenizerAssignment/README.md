# Introduction

This is a basic tokenizer built using Python and Regex (Regular Expressions). It first splits the text into sentences, then splits them further into tokens, before finding the frequency of each token and finally displaying both the type-token ratio of each sentence and also type-token ratio of the total corpus. 

The selected corpus was "The Project Gutenberg eBook of The Odyssey."

# Instructions on Running File

1. The input file for Task 1, entitled `i1.txt`, refers to the corpus text.
2. The input file for Task 2, entitled `i2.txt`, refers to the output file from Task 1.
3. The input file for Task 3, entitled `i3.txt`, refers to the output file from Task 2.
4. The first input file for Task 4, entitled `i4.txt`, refers to the output file from Task 2.
5. The second input file for Task 4, entitled `i4_2.txt`, refers to the output file from Task 3.

# Assumptions

1. Possessive use of apostrophes (ie. "Dave's", as in belonging to Dave) leads to the entire word being considered one token. 

# Notes

1. Input files are provided for convenience.