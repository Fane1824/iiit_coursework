import re 

f = open("i3.txt", "r")
l = f.readlines()
ans = {}
for x in range(len(l)):
    if (l[x].startswith("\tToken")):
        tok = l[x].split("=", 1)
        vex = tok[1].strip()
        v = vex.lower()
        if (v in ans):
            ans[v] += 1
        else:
            ans[v] = 1
f.close()
f2 = open("o3.txt", "w")
for key, value in ans.items():
    f2.write(key+" "+str(value)+"\n")
f2.close()
