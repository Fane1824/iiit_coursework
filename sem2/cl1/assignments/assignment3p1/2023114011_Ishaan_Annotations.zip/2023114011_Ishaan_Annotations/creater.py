import matplotlib.pyplot as plt
from collections import Counter

def graph_creator(filename, language):
    with open(filename, 'r') as file:
        lines = file.readlines()
    file.close()
    second_terms = []
    for line in lines:
        x = line.split("\t")
        if len(x) > 1:
            second_terms.append(x[1])
    frequency_count = Counter(second_terms)
    types = list(frequency_count.keys())
    frequencies = list(frequency_count.values())
    plt.figure(figsize=(10, 6))
    plt.bar(types, frequencies, color='skyblue')
    plt.xlabel('Part of Speech')
    plt.ylabel('Frequency')
    plt.title('Frequency of Each POS in '+language)
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()

graph_creator("English_Annotations.txt", "English")
graph_creator("French_Annotations.txt", "French")
