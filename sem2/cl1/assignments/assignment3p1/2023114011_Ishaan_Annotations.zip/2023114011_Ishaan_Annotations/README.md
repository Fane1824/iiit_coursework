# Introduction

This is a basic Part-of-speech (POS) tagger built using the Bureau of Indian Standards (BIS) POS Tagset. It annotates two corpora -- one in the French language, the other in English.

# English Language Corpus

The corpus taken is an excerpt from the speech given by U.S. President Ronald Reagan in Berlin, famous for the demand to the Soviet leader Mikhail Gorbhachev, "Tear down this wall!" 

The full speech can be accessed here (note that only the first five paragraphs were taken):

https://www.historyplace.com/speeches/reagan-tear-down.htm

# French Language Corpus

The corpus taken is an excerpt from a newspaper article in the French language newspaper "Le Monde" on the Israeli military operation in the Gaza Strip.

The full article can be accessed here (note that only the first nine paragraphs were taken):

https://www.lemonde.fr/international/article/2024/03/10/guerre-israel-hamas-des-dizaines-de-morts-a-gaza-apres-des-raids-israeliens-menes-a-la-veille-du-ramadan_6221175_3210.html

